












/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package POEpart1;

/**
 *
 * @author Asus
 */
import javax.swing.JOptionPane;
public class Application {
public static String NumberTask;
public static int statusChoice;
public static String taskName;
public static String taskDescription;        
public static String developerFirstName;
public static String developerLastName;
public static String developerDetails;
public static String taskDuration;
public static int taskNumber=0;
public static String taskStatus;
public static String taskID;
    public static void main(String[] args) {
        boolean continueLoop = true;
        boolean taskLoop = true;
        while (continueLoop){
        int mainChoice=showMainMenu();
          switch (mainChoice){
            case 1:   
                Registration.RegProcess();
                break;
            case 2:
                loginUser();
                JOptionPane.showMessageDialog(null,"Welcome to EasyKanban.");
                while (taskLoop){
                    int taskChoice=taskMainMenu();
                    switch (taskChoice){
                          case 1:   
                        NumberTask=JOptionPane.showInputDialog("Enter the number of tasks you would like to add.");
                        int IntNumberTask=0;
                        JOptionPane.showConfirmDialog(null,"Confirm the number of tasks:"+NumberTask);
                        try{
                            IntNumberTask=Integer.parseInt(NumberTask);
                        }catch(NumberFormatException e){
                            JOptionPane.showMessageDialog(null,"Invalid input.Please enter a valid number.");
                            break;
                        }
                        for(int TN=0;TN<IntNumberTask;TN++){
                        taskName=JOptionPane.showInputDialog("Enter the name of the new task");
                        JOptionPane.showConfirmDialog(null,"Confirm the name of the task:\n"+taskName);
                        taskDescription=JOptionPane.showInputDialog("Enter a task description(May not exceed 50 characters.)");
                        JOptionPane.showConfirmDialog(null,"Confirm the task description:\n"+taskDescription);
                        developerFirstName=JOptionPane.showInputDialog("Enter the your first name");
                        developerLastName=JOptionPane.showInputDialog("Enter the your last name");
                        JOptionPane.showConfirmDialog(null,"Confirm the detail of the developer(You)\n:"+Application.DeveloperDetails());
                        taskDuration=JOptionPane.showInputDialog("Enter the estimated duration of the task (In hours)");
                        boolean statusLoop=true;
                        while (statusLoop){
                            statusChoice=statusMainMenu();
                            switch(statusChoice){
                                case 1:
                                    JOptionPane.showMessageDialog(null,"Marked as TO DO.");
                                    statusLoop=false;
                                    break;
                                case 2:
                                   JOptionPane.showMessageDialog(null,"Marked as DOING.");
                                   statusLoop=false;
                                    break;
                                case 3:
                                    JOptionPane.showMessageDialog(null,"Marked as DONE.");
                                    statusLoop=false;
                                    break;
                                default:
                                    JOptionPane.showMessageDialog(null,"Invalid choice");
                                    break;
                            }
                         taskStatus=String.valueOf(statusChoice);
                            Task.printTaskDetails();    
                        }
 Task.returnTotalHours();        
}
                    
                break;

            case 2:
                JOptionPane.showMessageDialog(null,"Coming soon...");
                break;
            case 3:
                JOptionPane.showMessageDialog(null,"Exiting...");
                taskLoop=false;
                break; 
            default:
                JOptionPane.showMessageDialog(null,"Invalid choice");
                break; 
                    
                }
}        
                break;
            case 3:
                JOptionPane.showMessageDialog(null,"exiting...");
                continueLoop=false;
                break; 
            default:
                JOptionPane.showMessageDialog(null,"Invalid choice");
                break;
        }
        }           
    }
   
    public static int showMainMenu(){
        int choice=-1;
        try{
            choice=Integer.parseInt(JOptionPane.showInputDialog(
                "Welcome to the Registration and Login system\n"+
                "1. Register\n"+
                "2. Login\n"+
                "3. Exit\n"+
                "Enter your choice:"
        ));
    } catch(NumberFormatException e){
        JOptionPane.showMessageDialog(null,"Invalid input.Please enter a number");
    }
    return choice;
  }        
    public static void registerUser(){
        Registration.userGen();
        Registration.PasswordGen();
       if(POEpart1.Login.checkUserName(Registration.username)&&POEpart1.Login.checkPasswordComplexity(Registration.password)){ 
           JOptionPane.showMessageDialog(null,"Registration successful!");
       }else{
           JOptionPane.showMessageDialog(null,"Registration failed!");
       }
    }
    public static void loginUser(){
        String loginStatus=Login.returnLoginStatus();
        if ("Login successful".equals(loginStatus)){
           JOptionPane.showMessageDialog(null,"Login successful!");
    }else{
            JOptionPane.showMessageDialog(null,"Login failed"
            );
        }
    }
    
    public static int taskMainMenu(){
        int choice=-1;
        try{
            choice=Integer.parseInt(JOptionPane.showInputDialog(
            "Please select your desired action\n"+
                    "1. Add tasks\n"+
                    "2. Show report\n"+
                    "3. Quit\n"+
                    "Enter your choice:"
    ));    
        } catch(NumberFormatException e){
        JOptionPane.showMessageDialog(null,"Invalid input.Please enter a number");
    }
    return choice;
  }        
    public static int statusMainMenu(){
        int choice=-1;
        try{
            choice=Integer.parseInt(JOptionPane.showInputDialog(
                    "Please select an option\n"+
                            "1.To do\n"+
                            "2.Doing\n"+
                            "3.Done\n"+
                            "Enter your choice:"
            ));
    }catch(NumberFormatException e){
        JOptionPane.showMessageDialog(null,"Invalid choice.Please enter a number");
    }
    return choice;
    }
   public static String taskNumber(){
       taskNumber++;
       return String.format("%02d",taskNumber);
   }
   public static String DeveloperDetails(){
       return developerFirstName +" "+developerLastName;
   }
   public static String TaskStatus(){
       if ("1".equals(taskStatus)){
           JOptionPane.showMessageDialog(null,"To Do");
           return taskStatus;
       }else if("2".equals(taskStatus)){
           JOptionPane.showMessageDialog(null,"Doing");
           return taskStatus;
       }else if("3".equals(taskStatus)){
           JOptionPane.showMessageDialog(null,"Done");
           return taskStatus;
       }else{
            JOptionPane.showMessageDialog(null,"Invalid Status");   
       }
       return null;
}
}
