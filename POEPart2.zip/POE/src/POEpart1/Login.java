/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package POEpart1;

/**
 *
 * @author Asus
 */
import javax.swing.JOptionPane;
public class Login {
    public static String enteredUser;
    public static String enteredPassword;
    
    public static boolean checkUserName(String username){
        if (Registration.username!=null&&Registration.username.contains("_")&&Registration.username.length()<=5) {   
            JOptionPane.showMessageDialog(null,"Username successfully captured: "+username);
            return true;
        }else{
            JOptionPane.showMessageDialog(null,"Username is not correctly formatted,please ensure that your username contains an underscore and is no more than 5 characters in length");
            return false;
        }
    }
    
    public static boolean checkPasswordComplexity(String password){
            if (Registration.password!=null&&Registration.password.length()>=8&&Registration.password.matches(".*[A-Z].*")&&Registration.password.matches(".*\\d.*")&&Registration.password.matches(".*[!@#$%^&()-+=?<>].*")){
                JOptionPane.showMessageDialog(null,"Password is successfully captured: "+password);
                return true;
            }else{
                JOptionPane.showMessageDialog(null,"Password is not correctly formatted,please ensure that the password contains at least 8 characters,a capital letter,a number and a special character");
                return false;        
            }
       }    
        
    public static String registerUser(String username,String password){    
            if (!(Login.checkUserName(username))){
                JOptionPane.showMessageDialog(null,"the username is incorrectly formatted.");
            return "Username format is incorrect";
            }
            if (!(checkPasswordComplexity(password))){
                JOptionPane.showMessageDialog(null,"The password does not meet the complexity requirements.");
            return "password complexity requirements not met";
            }
                JOptionPane.showMessageDialog(null,"Both of the above conditions have been met and the user has been successfully registered");
            return "user successfully registered";
        }    
    
    public static boolean logingUser(){
        enteredUser=JOptionPane.showInputDialog(null,"Enter your username:");
        enteredPassword=JOptionPane.showInputDialog(null,"Enter your password:");   
        if (enteredUser.equals(POEpart1.Registration.username)&&enteredPassword.equals(POEpart1.Registration.password)){
        JOptionPane.showMessageDialog(null,"Welcome "+POEpart1.Registration.firstName+", "+POEpart1.Registration.lastName+" it is great to see you again.");
        return true;
        }else{
            JOptionPane.showMessageDialog(null,"Username or password incorrect,please try again");
            Application.showMainMenu();
            return false;
        }
    }
    public static String returnLoginStatus(){
        if (logingUser()){
        return "Login Successful";
    }else{
            return "Login Failed" ;
         }
    }
    
}
